This issue tracker is for proposing new examples or specific changes to existing examples. Please ask "how-to" questions on https://stackoverflow.com/ instead. If you're having trouble with OSMnx, please open an issue at the OSMnx repo: https://github.com/gboeing/osmnx/issues

Before you proceed, please read the contributing guidelines in this repo's CONTRIBUTING.md.

Any issues opened here **will be automatically closed** unless they propose new examples or specific changes to existing examples.

PRs welcome for new examples!
